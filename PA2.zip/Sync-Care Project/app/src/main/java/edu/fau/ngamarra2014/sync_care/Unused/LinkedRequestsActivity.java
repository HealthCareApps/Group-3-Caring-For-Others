package edu.fau.ngamarra2014.sync_care.Unused;

import android.app.Activity;
import android.os.Bundle;

import edu.fau.ngamarra2014.sync_care.R;


public class LinkedRequestsActivity extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.z_linked_requests);
    }
}
