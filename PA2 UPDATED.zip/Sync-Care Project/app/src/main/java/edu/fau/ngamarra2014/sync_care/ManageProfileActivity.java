package edu.fau.ngamarra2014.sync_care;

import android.app.Activity;
import android.os.Bundle;


public class ManageProfileActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_profile);
    }

}
