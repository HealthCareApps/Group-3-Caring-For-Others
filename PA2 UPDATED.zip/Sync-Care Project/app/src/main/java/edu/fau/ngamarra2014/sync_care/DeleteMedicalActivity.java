package edu.fau.ngamarra2014.sync_care;

import android.app.Activity;
import android.os.Bundle;


public class DeleteMedicalActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.information_balance_checklist);
    }

}
